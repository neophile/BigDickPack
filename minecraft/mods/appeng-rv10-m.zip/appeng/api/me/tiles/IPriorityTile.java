package appeng.api.me.tiles;

public interface IPriorityTile
{
	int getPriority();	
	void setPriority( int p );	
}
