package appeng.api;

public interface IExternalStorageRegistry {
	
	void addExternalStorageInterface( IExternalStorageHandler ei );
	
}
